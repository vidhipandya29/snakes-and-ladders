//Vidhi Pandya
//October 27th 2018
//Snakes and Ladders Game
public class SALFINAL
{
    public static void main (String Args [])
    {
        new SALFINAL ();
    }

    public SALFINAL ()
    {
        //set variables for player of # of square and sum of dice
        int square = 1;
        int dice = 2;

        //greet player and give them instructions
        System.out.println ("Welcome to Snakes and Ladders!!");
        System.out.println ("If you roll a sum of dice that is equivalent to 0 or 1, you quit the game!");

        //begin the game
        while (dice >=2 && dice<=12 && square<=100)
        {
            //ask user to enter sum
            dice = IBIO.inputInt ("Enter sum of dice (between 2 and 12): ");

            //after each roll, add sum of dice to get the square # that user is on
            square = dice + square;

            //what happens if you are on a square that is a snake or ladder
            if (square == 54)
            {
                square = 19;
                System.out.println ("OH NO! A SNAKE!");
            }
            else if (square == 90)
            {
                square = 48;
                System.out.println ("OH NO! A SNAKE!");
            }

            else if (square == 99)
            {
                square = 77;
                System.out.println ("OH NO! A SNAKE!");
            }

            else if (square == 9)
            {
                square = 34;
                System.out.println ("YAY! A LADDER!");
            }

            else if (square == 40)
            {
                square = 64;
                System.out.println ("YAY! A LADDER!");
            }

            else if (square == 67)
            {
                square = 86;
                System.out.println ("YAY! A LADDER!");
            }

            if (square<=100){
                //tell the user what square they are on
                System.out.println ("You are now on square: " +square);
            }
        }

        //if user rolls a sum less than or equal to 1, or greater than 12, they quit
        if (dice <=1 || dice>12)
        {
            System.out.println ("You quit!!");
        }
        //if the user lands on 100 or past it, they win
        if (square>=100)
        {
            System.out.println ("YOU WON!!");
        }
    }
}
